<?php

class Mercado_model extends CI_Model {


    function __construct()
    {
                parent::__construct();
                
        
    }

       function get_current_page_records($limit, $start, $tx_busqueda)
    {

  
                $sql="SELECT
                    a.nb_producto_sicm,
                    (
                        SELECT
                            ca_tasa_cambio
                        FROM
                            x00t_moneda_paralela
                        WHERE
                            DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                        LIMIT 1
                    ) AS ca_dolar,
                    AVG(
                        a.ca_precio / (
                            SELECT
                                ca_tasa_cambio
                            FROM
                                x00t_moneda_paralela
                            WHERE
                                DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                            LIMIT 1
                        )
                    ) AS promedio
                FROM
                    j074t_guia_movilizacion_precio AS a,
                    j072t_guia_movilizacion AS b
                WHERE
                    CHAR_LENGTH(ca_precio) > 8
                AND b.nu_guia = a.nu_guia
                AND a.nb_producto_sicm != 'NO EXISTE'
                GROUP BY
                    1,
                    2
                ORDER BY
                    a.nb_producto_sicm ASC limit $start, $limit";
        $query=$this->db->query($sql);
        return $query;
    }

           function get_productos_demanda()
    {

  
                        $sql="SELECT
            a.nb_producto_sicm,
            (
                SELECT
                    ca_tasa_cambio
                FROM
                    x00t_moneda_paralela
                WHERE
                    DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                LIMIT 1
            ) AS ca_dolar,
            AVG(
                a.ca_precio / (
                    SELECT
                        ca_tasa_cambio
                    FROM
                        x00t_moneda_paralela
                    WHERE
                        DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                    LIMIT 1
                )
            ) AS promedio,
            AVG(a.ca_unidades) AS ca_unidades,
            MAX(
                a.ca_precio / (
                    SELECT
                        ca_tasa_cambio
                    FROM
                        x00t_moneda_paralela
                    WHERE
                        DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                    LIMIT 1
                )
            ) AS precio_maximo,
            MIN(
                a.ca_precio / (
                    SELECT
                        ca_tasa_cambio
                    FROM
                        x00t_moneda_paralela
                    WHERE
                        DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                    LIMIT 1
                )
            ) AS precio_minimo
        FROM
            j074t_guia_movilizacion_precio AS a,
            j072t_guia_movilizacion AS b
        WHERE
            CHAR_LENGTH(ca_precio) > 8
        AND b.nu_guia = a.nu_guia
        AND a.nb_producto_sicm != 'NO EXISTE'
        GROUP BY
            1,
            2
        ORDER BY
            4 DESC
        LIMIT 25";

        $query=$this->db->query($sql);
        return $query;
    }

    // Producto especifico

               function get_producto_especifico($nb_producto)
    {

  
                $sql="SELECT
                    a.nb_producto_sicm,
                    (
                        SELECT
                            ca_tasa_cambio
                        FROM
                            x00t_moneda_paralela
                        WHERE
                            DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                        LIMIT 1
                    ) AS ca_dolar,
                    AVG(
                        a.ca_precio / (
                            SELECT
                                ca_tasa_cambio
                            FROM
                                x00t_moneda_paralela
                            WHERE
                                DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                            LIMIT 1
                        )
                    ) AS promedio,
                    AVG(a.ca_unidades) AS ca_unidades,
                    MAX(
                        a.ca_precio / (
                            SELECT
                                ca_tasa_cambio
                            FROM
                                x00t_moneda_paralela
                            WHERE
                                DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                            LIMIT 1
                        )
                    ) AS precio_maximo,
                    MIN(
                        a.ca_precio / (
                            SELECT
                                ca_tasa_cambio
                            FROM
                                x00t_moneda_paralela
                            WHERE
                                DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                            LIMIT 1
                        )
                    ) AS precio_minimo
                FROM
                    j074t_guia_movilizacion_precio AS a,
                    j072t_guia_movilizacion AS b
                WHERE
                    CHAR_LENGTH(ca_precio) > 8
                AND b.nu_guia = a.nu_guia
                AND a.nb_producto_sicm = '$nb_producto'
                GROUP BY
                    1,
                    2
                ORDER BY
                    4 DESC
                LIMIT 25";
        $query=$this->db->query($sql);
        return $query;
    }

    

               function buscar_producto_mercado_model($limit, $start, $tx_busqueda)
    {

        $filtro = '';
        $filtro_producto = '';
        if ($this->ion_auth->tipo_empresa() == 'DROGUERIA'):
            $filtro = "and b.nb_tipo_empresa_origen REGEXP 'Drogueria' and b.nb_tipo_empresa_destino REGEXP 'Farmacia'";
        endif;

        if ($this->ion_auth->tipo_empresa() == 'CASA DE REPRESENTACION'):
            $filtro = "and b.nb_tipo_empresa_origen REGEXP 'CASA DE REPRESENTACION' and b.nb_tipo_empresa_destino REGEXP 'Drogueria'";
        endif;

        if ($tx_busqueda != ''): 

            $filtro_producto = " AND a.nb_producto_sicm REGEXP '$tx_busqueda'"; 

        endif;

                            $sql="SELECT
                a.nb_producto_sicm,
                (
                    SELECT
                        ca_tasa_cambio
                    FROM
                        x00t_moneda_paralela
                    WHERE
                        DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                    LIMIT 1
                ) AS ca_dolar,
                AVG(
                    a.ca_precio / (
                        SELECT
                            ca_tasa_cambio
                        FROM
                            x00t_moneda_paralela
                        WHERE
                            DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                        LIMIT 1
                    )
                ) AS promedio,
                AVG(a.ca_unidades) AS ca_unidades,
                MAX(
                    a.ca_precio / (
                        SELECT
                            ca_tasa_cambio
                        FROM
                            x00t_moneda_paralela
                        WHERE
                            DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                        LIMIT 1
                    )
                ) AS precio_maximo,
                MIN(
                    a.ca_precio / (
                        SELECT
                            ca_tasa_cambio
                        FROM
                            x00t_moneda_paralela
                        WHERE
                            DATE_FORMAT(ff_sistema, '%Y-%m-%d') <= b.ff_emision_date
                        LIMIT 1
                    )
                ) AS precio_minimo
            FROM
                j074t_guia_movilizacion_precio AS a,
                j072t_guia_movilizacion AS b
            WHERE
                CHAR_LENGTH(ca_precio) > 8
            AND b.nu_guia = a.nu_guia
            $filtro_producto $filtro
            GROUP BY
                1,
                2
            ORDER BY
                4 DESC
            limit $start, $limit";

        $query=$this->db->query($sql);
        return $query;
    }


                 function get_total($tx_busqueda)
    {

             $filtro = '';
             $filtro_producto = '';
        if ($this->ion_auth->tipo_empresa() == 'DROGUERIA'):
            $filtro = "and b.nb_tipo_empresa_origen REGEXP 'Drogueria' and b.nb_tipo_empresa_destino REGEXP 'Farmacia'";
        endif;

        if ($this->ion_auth->tipo_empresa() == 'CASA DE REPRESENTACION'):
            $filtro = "and b.nb_tipo_empresa_origen REGEXP 'CASA DE REPRESENTACION' and b.nb_tipo_empresa_destino REGEXP 'Drogueria'";
        endif;

        if ($tx_busqueda != ''): 

            $filtro_producto = " AND a.nb_producto_sicm REGEXP '$tx_busqueda'"; 

        endif;


                            $sql="SELECT
            a.nu_guia
            FROM
                j074t_guia_movilizacion_precio AS a,
                j072t_guia_movilizacion AS b
            WHERE
                CHAR_LENGTH(ca_precio) > 8
            AND b.nu_guia = a.nu_guia
            $filtro_producto $filtro
            GROUP BY
                1";
        $query=$this->db->query($sql);
        return $query->num_rows();
    }




    


    



}
?>