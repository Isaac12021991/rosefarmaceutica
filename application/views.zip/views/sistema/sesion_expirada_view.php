<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>

    <h4 class="modal-title">Sesion Expirada</h4>
</div>
<div class="modal-body">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <p> Por seguridad el la sesion se ha cerrado, por favor vuelva iniciar sesion para contuinuar. </p>
        </div>

    </div>
    </div>


    <div class="modal-footer">
    <a href="<?php echo site_url('auth/logout')?>" class="btn default" data-dismiss="modal">Cerrar</a>

</div>

