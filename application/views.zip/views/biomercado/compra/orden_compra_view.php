                    <div class="content d-flex flex-column flex-column-fluid" id="kt_content">
                        <!--begin::Subheader-->
                        <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
                            <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
                                <!--begin::Info-->
                                <!--begin::Info-->
                                <div class="d-flex align-items-center flex-wrap mr-2">
                                                           <a href="javascript:window.history.back();"class="btn btn-clean btn-xs p-2 mr-2 d-block d-md-none">
                                    <i class="fas fa-arrow-left"></i> 
                                    </a>

                                    <!--begin::Actions-->
                                    <h5 id="controlador" class="text-dark font-weight-bold mt-2 mb-2 mr-5">Compras</h5>
                                        <ul class="breadcrumb breadcrumb-transparent breadcrumb-dot font-weight-bold p-0 my-2 font-size-sm">
                                            <li class="breadcrumb-item text-muted">
                                                <a href="" class="text-muted">Ordenes de compra</a>
                                            </li>
                                        </ul>


        
                                </div>
                                <!--end::Info-->
                                <!--begin::Toolbar-->
                                <div class="d-flex align-items-center">

                  
        
                                    <!--end::Actions-->
                                    <!--begin::Dropdown-->
                                            <!--end::Dropdown-->
                                </div>
                                <!--end::Toolbar-->
                            </div>
                        </div>
                        <!--end::Subheader-->
                        <!--begin::Entry-->
                        <div class="d-flex flex-column-fluid">
                            <!--begin::Container-->
                            <div class="container animsition">
                                <div class="row">

                                <div class="col-lg-1">
                                    
                                    
                                </div>

                                <div class="col-lg-10 pl-0 pr-0">


                                    <div class="card card-custom gutter-b">
                                    <div class="card-header">
                                    <div class="card-title">
                                    <h3 class="card-label">
                                    Orden de compra
                                    <small>Ordenes de compras emitidas</small>
                                    </h3>
                                    </div>
                                    </div>
                                    <div class="card-body">


                                                                                                     <div class="row">
                                             <?php if (isset($listado_orden_compra)): ?>
                                         <?php if ($listado_orden_compra->num_rows() > 0) : ?>

                                        <?php $con = 0; foreach ($listado_orden_compra->result() as $row) : $con ++; ?>




                                                            <div class="col-lg-6 p-2 py-lg-4">
                                                                                    <div class="d-flex mb-0">
                                                    <!--begin::Symbol-->
                                                    <div class="symbol symbol-50 symbol-2by3 flex-shrink-0 mr-2">
                                                        <div class="d-flex flex-column">

                                                        <div class="bg-secondary p-6 mt-b"> <i class="fas fa-user mr-2"></i> <?php echo $row->username; ?> </div>

                                                          <?php if ($row->nb_estatus == 'En espera por aprobacion'): ?> <i class="symbol-badge bg-primary blink"></i> <?php else: ?> <i class="symbol-badge bg-dark"></i>  <?php endif; ?>

                                                          <a href="<?php echo site_url("compra/detalle_orden_compra/$row->id");?>" class="btn btn-light-primary btn-sm font-weight-bold p-1 mt-1">Ver orden</a>



                                                             <?php if ($row->nb_estatus == 'Cancelado por el comprador' or $row->nb_estatus == 'Confirmado por el vendedor' or $row->nb_estatus == 'Cancelado por el vendedor'): ?>

                                                                     <?php if (!$this->biomercado_library->get_info_calificado($row->id)): ?>


                                                          <a href="javascript:"  onclick="abrir_modal('<?php echo $row->id; ?>')" class="btn btn-light-primary btn-sm font-weight-bold p-1 mt-1">Calificar usuario</a>



                                                                        <?php endif; ?>
                                                                        <?php endif; ?>

                                                                         <?php if ($row->nb_estatus == 'Confirmado por el comprador'): ?>

                                                                    <a href="javascript:" onclick="cancelar_orden_compra('<?php echo $row->id; ?>')" class="btn btn-light-primary btn-sm font-weight-bold p-1 mt-1">Cancelar orden</a>

                                                                            <?php endif; ?>



                                                     <?php if ($this->biomercado_library->get_info_calificado($row->id) or $row->nb_estatus == 'Orden de compra abandonada'  or $row->nb_estatus == 'Orden de compra cancelada por el vendedor' or $row->nb_estatus == 'Rechazado por el comprador'): ?>

                                                         <a class="btn btn-light-primary btn-sm font-weight-bold p-1 mt-1"href="javascript:"  onclick="remover_orden_compra('<?php echo $row->id; ?>')" >Remover</a>


                                                        <?php endif; ?>




                                            <?php if ($row->nb_estatus == 'En espera por aprobacion'): ?> 
                                                        <div class="btn-group btn-sm p-1" role="group" aria-label="Basic example">
                                                    <button onclick="aprobar_orden_compra('<?php echo $row->id; ?>','<?php echo $row->nu_codigo_orden_compra; ?>')" class="btn btn-light-success btn-sm p-1"><i class="fa fa-check"></i></button>
                                                    <button onclick="rechazar_orden_compra('<?php echo $row->id; ?>','<?php echo $row->nu_codigo_orden_compra; ?>')" class="btn btn-light-danger btn-sm p-1"><i class="fa fa-times"></i></button>
                                                </div>

                                            <?php endif; ?>

                                                        


                                                        </div>
                                                    </div>
                                                    <!--end::Symbol-->
                                                    <!--begin::Title-->
                                                    <div class="d-flex flex-column flex-grow-1 my-lg-0 my-0 pr-0">


                                                           <span class="text-muted font-size-xs">  <?php $fecha_elaboracion = date("d-m-Y g:i:s a", $row->ff_fecha_elaboracion); 
                                                         echo "Hace ".time_stamp($fecha_elaboracion); ?> </span>


                                                        <a href="javascript:" class="text-dark-75 font-weight-bolder text-hover-primary font-size-lg" onclick="ver_detalle_orden('<?php echo $row->id; ?>')"> N° <?php echo $row->nu_codigo_orden_compra; ?></a>

                                                        <span class="text-dark font-size-sm mb-0"> <?php if ($row->nb_estatus == 'En espera por aprobacion'): ?> <span class="font-size-md text-primary"><?php echo $row->nb_estatus; ?></span> <?php else: ?> <span class="font-size-md text-dark"><?php echo $row->nb_estatus; ?></span> <?php endif; ?></span>
                                                        <?php if($row->ca_pagado > 0): ?>
                                                        <span class=" text-primary font-size-sm">Pagado</span>
                                                         <?php endif; ?>


                                                             <div class="row mb-0 pl-4">

                                                                 <table class="table table-sm table-light">
      
                                                                      <tr>
                                                                        <td><i class="fas fa-dollar-sign text-dark"></i></td>
                                                                        <td><?php echo number_format($row->ca_monto,2,',','.').' '.$row->nb_acronimo; ?></td>
                                                                        <td><i class="fas fa-industry text-dark"></i></td><td> <?php echo $row->nb_empresa_vendedor; ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                 <td><i class="far fa-star text-warning"></i></td><td id="td_calificado_<?php echo $row->id; ?>">

                                                                            <?php if (!$this->biomercado_library->get_info_calificado($row->id)): ?>
                                                                <span class="text-danger">Sin Calificar </span> 
                                                               
                                                            <?php else: ?>

                                                                <span class="text-info">Calificado </span> 

                                                                <?php endif; ?>
                                                            </span></td>

                                                              <td><i class="fas fa-map-marker text-dark"></i></td>
                                                                        <td><?php echo $row->nb_estado_vendedor; ?> </td>

                                                                    </tr>



                                                                </table>


                                                              

                                                           

   

                                                            </div>

            
                                                    </div>
                                                    <!--end::Title-->
                                                </div>

                                                </div>

                                  
                                                       <?php endforeach; ?>  

                                                       <?php else: ?>
                            <div class="p-8">
                                         <h4>Sin Registro</h4>
                    <p>Todas las ordenes de compra que emita de su proveedor aparecerán aqui</p>
                </div>

            <?php endif; ?>



            <?php else: ?>

                            <div class="p-8">
                                         <h4>Sin Registro</h4>
                    <p>Todas las ordenes de compra que emita de su proveedor aparecerán aqui</p>
                </div>

             <?php endif; ?>


    


                                                </div>


          

                                    </div>
                                    </div>

                                          



    

                            </div>



















                                <div class="col-lg-1"></div>

                            </div>

                            </div>
                            <!--end::Container-->
                        </div>
                        <!--end::Entry-->
                    </div>


    <div class="modal fade"  id="ajax_remote" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog"  role="document">
        <div class="modal-content">
            <h3 align="center" class="text-dark">Cargando...</h3>

        </div>
    </div>
</div>


<script type="text/javascript">

    function ver_detalle_orden(co_orden_compra) {

     $(location).attr('href',"<?php echo site_url() ?>compra/detalle_orden_compra/"+co_orden_compra); 

}


   $(document).ready(function(){

    
      jQuery('#ajax_remote').on('hidden.bs.modal', function (e) {
    jQuery(this).removeData('bs.modal');
    jQuery(this).find('.modal-content').html('<h3 align="center" class="text-dark">Cargando...</h3>');
   })
   

   }); // Fin ready
   
                function abrir_modal(co_orden_compra) {

                        $('#ajax_remote').modal('show');
                            $.get("<?php echo site_url('compra/calificar_proceso') ?>"+"/"+co_orden_compra,
                            function(data){
                            if (data != "") {
                                $('#ajax_remote').modal('show');
                                $('#ajax_remote .modal-content').html(data);
                            }            
                                      }

                            );  

                            
                            }



   
     function cancelar_orden_compra(co_orden_compra) {
   $.confirm({
   backgroundDismiss: false,
   backgroundDismissAnimation: 'glow',
   theme: 'material', 
   title: 'Cancelar orden de compra',
   content: '¿Deseas cancelar esta orden de compra?',
    type: 'red',
   animation: 'opacity',
   escapeKey: 'no',
   buttons: {   
   si: function () {
   $.ajax({
    method: "POST",
    data: {'co_orden_compra':co_orden_compra},
    url: "<?php echo site_url('compra/cancelar_orden_compra') ?>",
    }).done(function( data ) { 
        var obj = JSON.parse(data);

        location.reload();

        }).fail(function(){
            alert('Fallo');
        }); 
    },
    no: function () {
    },
   }
   });
   }
                    

     function remover_orden_compra(co_orden_compra) {
   $.confirm({
   backgroundDismiss: true,
   backgroundDismissAnimation: 'glow',
   theme: 'material', 
   title: 'Remover orden de compra',
   content: '¿Deseas remover esta orden de compra?',
    type: 'blue',
   animation: 'opacity',
   escapeKey: 'no',
   buttons: {   
   si: function () {
   $.ajax({
    method: "POST",
    data: {'co_orden_compra':co_orden_compra},
    url: "<?php echo site_url('compra/remover_orden_compra') ?>",
    }).done(function( data ) { 
        var obj = JSON.parse(data);

        location.reload();

        }).fail(function(){
            alert('Fallo');
        }); 
    },
    no: function () {
    },
   }
   });
   }


            function aprobar_orden_compra(co_orden_compra, nu_orden_compra)
   {
   

   
                       $.confirm({
   backgroundDismiss: false,
   backgroundDismissAnimation: 'glow',
   theme: 'material', 
   title: 'Aprobar',
   content: '¿Estas seguro que deseas aprobar esta orden de compra N°'+nu_orden_compra+' ?.',
   type: 'blue',
   animation: 'opacity',
   autoClose: 'no|10000',
   escapeKey: 'no',
   buttons: {
   si: function () {
   
                                          $.ajax({
   method: "POST",
   data: {'co_orden_compra':co_orden_compra, 'nb_estatus':'Confirmado por el comprador'},
   url: "<?php echo site_url('compra/cambiar_estatus_orden_compra') ?>",
   beforeSend: function(){  },
            }).done(function( data ) { 
   
               var obj = JSON.parse(data);
   
              toastr.info("Exito", obj.message);
   
           location.reload();
   
             }).fail(function(){
   
           alert('Fallo');
   
   
             }); 
   
   
   },
   no: function () {
   
   
   
   },
   
   }
   });
   
   
   
   
   }


         function rechazar_orden_compra(co_orden_compra, nu_orden_compra)
   {
   

   
                       $.confirm({
   backgroundDismiss: false,
   backgroundDismissAnimation: 'glow',
   theme: 'material', 
   title: 'Rechazar',
   content: '¿Estas seguro que deseas rechazar esta orden de compra N°'+nu_orden_compra+' ?.',
   type: 'red',
   animation: 'opacity',
   autoClose: 'no|10000',
   escapeKey: 'no',
   buttons: {
   si: function () {
   
                                          $.ajax({
   method: "POST",
   data: {'co_orden_compra':co_orden_compra, 'nb_estatus':'Rechazado por el comprador'},
   url: "<?php echo site_url('compra/cambiar_estatus_orden_compra') ?>",
   beforeSend: function(){  },
            }).done(function( data ) { 
   
               var obj = JSON.parse(data);
   
              toastr.info("Exito", obj.message);
   
           location.reload();
   
             }).fail(function(){
   
           alert('Fallo');
   
   
             }); 
   
   
   },
   no: function () {
   
   
   
   },
   
   }
   });
   
   
   
   
   }

             

   
   
</script>

