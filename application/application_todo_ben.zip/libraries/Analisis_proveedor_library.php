<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Analisis_proveedor_library {
    protected $ci;
    function __construct() {
        $this->ci =& get_instance();
        $obj =& get_instance();
    }
    // GENERAL
    function get_info_producto_co_analisis_proveedor_linea($co_analisis_porveedor_linea) {
        $obj =& get_instance();
        $sql  = "SELECT *
        FROM x043t_analisis_proveedor_linea as a
        where a.id = '$co_analisis_porveedor_linea' limit 1";

        $query = $obj->db->query($sql);
        return $query->row()    ;
    }

    function info_producto_proveedor($co_contacto, $nb_producto) {
        $obj =& get_instance();
        $sql  = "SELECT *, (SELECT MAX(ca_precio) as max_ca_precio FROM 
        x043t_analisis_proveedor_linea as a 
        where a.nb_producto = '$nb_producto' and in_activo = true) as max_ca_precio,
        (SELECT MIN(ca_precio) as min_ca_precio FROM 
        x043t_analisis_proveedor_linea as a 
        where a.nb_producto = '$nb_producto' and in_activo = true) as min_ca_precio
        FROM x043t_analisis_proveedor_linea as a
        join i002t_analisis_proveedor as b on b.id = a.co_analisis_proveedor
        join i00t_clientes as c on c.id = b.co_contacto
        join i00t_monedas as d on d.id = b.co_moneda
        where b.co_contacto = '$co_contacto' and a.nb_producto = '$nb_producto' limit 1";
        $query = $obj->db->query($sql);
        return $query;
    }

        function info_producto_proveedor_comparacion_precio_minimo($nb_producto) {
        $obj =& get_instance();

        $sql  = "SELECT a.ca_precio, c.nb_cliente FROM x043t_analisis_proveedor_linea as a join i002t_analisis_proveedor as b on b.id = a.co_analisis_proveedor join i00t_clientes as c on c.id = b.co_contacto join i00t_monedas as d on d.id = b.co_moneda where a.nb_producto = '$nb_producto' ORDER BY a.ca_precio asc limit 1";
        $query = $obj->db->query($sql);
        return $query->row();
    }


            function info_producto_proveedor_comparacion_precio_maximo($nb_producto) {

        $obj =& get_instance();
        $sql  = "SELECT a.ca_precio, c.nb_cliente FROM x043t_analisis_proveedor_linea as a join i002t_analisis_proveedor as b on b.id = a.co_analisis_proveedor join i00t_clientes as c on c.id = b.co_contacto join i00t_monedas as d on d.id = b.co_moneda where a.nb_producto = '$nb_producto' ORDER BY a.ca_precio desc limit 1";
        $query = $obj->db->query($sql);
        return $query->row();
    }


    


}
?>