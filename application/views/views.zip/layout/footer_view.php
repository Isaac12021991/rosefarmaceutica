

          <!--end::Content-->
          <!--begin::Footer-->
          <div class="footer bg-white py-4 d-flex flex-lg-column" id="kt_footer">
            <!--begin::Container-->
            <div class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between">
              <!--begin::Copyright-->
              <div class="text-dark order-2 order-md-1">

                <span class="text-muted font-weight-bold mr-2"><?php echo date('Y'); ?></span>

                <a href="http://keenthemes.com/metronic" target="_blank" class="text-dark-75 text-hover-primary"><?php $info_empresa = $this->empresa_library->get_info_empresa(); ?>
                  
                  <?php $co_partner = $this->ion_auth->co_partner(); echo $info_empresa->nb_empresa; ?>
                </a>

              </div>
              <!--end::Copyright-->
              <!--begin::Nav-->
              <div class="nav nav-dark">
                <a href="#" target="_blank" class="nav-link pl-0 pr-5"><?php echo $this->ion_auth->empresa(); ?></a>
                <a href="# " target="_blank" class="nav-link pl-0 pr-5"><?php echo $this->ion_auth->tipo_empresa(); ?></a>

                 <?php if($this->ion_auth->in_empresa_activado() == 0): ?> <a href='<?php echo site_url("partner/editar_partner/$co_partner"); ?>' class="nav-link pl-0 pr-5 text-info"> Verificar empresa</a> <?php endif; ?>


              </div>
              <!--end::Nav-->
            </div>
            <!--end::Container-->
          </div>
          <!--end::Footer-->
        </div>
        <!--end::Wrapper-->
      </div>
      <!--end::Page-->
    </div>
    <!--end::Main-->
    <!-- begin::User Panel-->
    <div id="kt_quick_user" class="offcanvas offcanvas-right p-10">
      <!--begin::Header-->
      <div class="offcanvas-header d-flex align-items-center justify-content-between pb-5">
        <h3 class="font-weight-bold m-0">Perfil
        <small class="text-muted font-size-sm ml-2"></small></h3>



        <a href="#" class="btn btn-xs btn-icon btn-light btn-hover-primary" id="kt_quick_user_close">
          <i class="ki ki-close icon-xs text-muted"></i>
        </a>
      </div>
      <!--end::Header-->
      <!--begin::Content-->
      <div class="offcanvas-content pr-5 mr-n5">
        <!--begin::Header-->
        <div class="d-flex align-items-center mt-5">
          <div class="symbol symbol-100 mr-5">
            <div class="symbol-label" style="background-image:url('<?php echo $this->ion_auth->foto_perfil(); ?>')"></div>
            <i class="symbol-badge bg-success"></i>
          </div>
          <div class="d-flex flex-column">
            <a href="<?php echo site_url('cuenta/cuenta')?>" class="font-weight-bold font-size-h5 text-dark-75 text-hover-primary"><?php echo $this->ion_auth->get_nombres(); ?></a>
            <div class="text-muted mt-1"><?php echo $this->ion_auth->username(); ?></div>
            <div class="navi mt-2">
              <a href="#" class="navi-item">
                <span class="navi-link p-0 pb-2">
                  <span class="navi-icon mr-1">
                    <span class="svg-icon svg-icon-lg svg-icon-primary">
                      <!--begin::Svg Icon | path:assets/media/svg/icons/Communication/Mail-notification.svg-->
                      <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                          <rect x="0" y="0" width="24" height="24" />
                          <path d="M21,12.0829584 C20.6747915,12.0283988 20.3407122,12 20,12 C16.6862915,12 14,14.6862915 14,18 C14,18.3407122 14.0283988,18.6747915 14.0829584,19 L5,19 C3.8954305,19 3,18.1045695 3,17 L3,8 C3,6.8954305 3.8954305,6 5,6 L19,6 C20.1045695,6 21,6.8954305 21,8 L21,12.0829584 Z M18.1444251,7.83964668 L12,11.1481833 L5.85557487,7.83964668 C5.4908718,7.6432681 5.03602525,7.77972206 4.83964668,8.14442513 C4.6432681,8.5091282 4.77972206,8.96397475 5.14442513,9.16035332 L11.6444251,12.6603533 C11.8664074,12.7798822 12.1335926,12.7798822 12.3555749,12.6603533 L18.8555749,9.16035332 C19.2202779,8.96397475 19.3567319,8.5091282 19.1603533,8.14442513 C18.9639747,7.77972206 18.5091282,7.6432681 18.1444251,7.83964668 Z" fill="#000000" />
                          <circle fill="#000000" opacity="0.3" cx="19.5" cy="17.5" r="2.5" />
                        </g>
                      </svg>
                      <!--end::Svg Icon-->
                    </span>
                  </span>
                  <span class="navi-text text-muted text-hover-primary"><?php echo $this->ion_auth->get_email(); ?></span>
                </span>
              </a>
              <a href="<?php echo site_url('auth/logout')?>" class="btn btn-sm btn-light-primary font-weight-bolder py-2 px-5">Cerrar Sesion</a>
            </div>
          </div>
        </div>

        <!--end::Nav-->
        <!--begin::Separator-->
        <div class="separator separator-dashed my-7"></div>
        <!--end::Separator-->

                <a href="<?php echo site_url('cuenta/cuenta')?>" class="btn btn-sm btn-light-primary">
    <i class="flaticon-settings"></i> Ajustes
</a>
        <!--begin::Notifications-->
        <div>
           <div class="separator separator-dashed my-7"></div>
            <?php $info_notificaciones = $this->auditoria->notificaciones(); ?>
          <!--begin:Heading-->
          <?php if($info_notificaciones->num_rows() > 0): ?>
          <h5 class="mb-5">Notificaciones recientes</h5>
        <?php else: ?>
           <h5 class="mb-5">Sin notificaciones</h5>
        <?php endif; ?>
          <!--end:Heading-->
          <!--begin::Item-->
          

            <?php foreach ($info_notificaciones->result() as $row): ?>

          <div class="alert alert-custom alert-light-primary fade show mb-5" role="alert">
    <div class="alert-icon"><i class="flaticon-warning"></i></div>
    <div class="alert-text"><?php echo $row->tx_descripcion; ?></div>
    <div class="alert-close">
        <button type="button" onclick="cerrar_notificacion('<?php echo $row->id; ?>')" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="ki ki-close"></i></span>
        </button>
    </div>
</div>

           <?php endforeach; ?>
          <!--end::Item-->
          <!--end::Item-->
        </div>
        <!--end::Notifications-->
      </div>
      <!--end::Content-->
    </div>
    <!-- end::User Panel-->

        <div id="kt_quick_cart" class="offcanvas offcanvas-right p-10">

          <span id="reload_carrito">
      <!--begin::Header-->
      <div class="offcanvas-header d-flex align-items-center justify-content-between pb-7">
        <h4 class="font-weight-bold m-0">Carro de compra</h4>
        <a href="#" class="btn btn-xs btn-icon btn-light btn-hover-primary" id="kt_quick_cart_close">
          <i class="ki ki-close icon-xs text-muted"></i>
        </a>
      </div>
      <!--end::Header-->
      <!--begin::Content-->
      <div class="offcanvas-content">
        <!--begin::Wrapper-->
        <div class="offcanvas-wrapper mb-5 scroll-pull">

           <?php $ca_monto = 0; $info_carrito = $this->biomercado_library->get_info_comprado_general(); ?>

                                                        <?php if($info_carrito->num_rows()): ?>
                                                <?php foreach ($info_carrito->result() as $row): ?>
          <!--begin::Item-->
          <div class="d-flex align-items-center justify-content-between py-8">
            <div class="d-flex flex-column mr-2">
              <a href="<?php echo site_url(); ?>compra/menu_carro" class="font-weight-bold text-dark-75 font-size-lg text-hover-primary"><?php echo $row->nb_producto; ?></a>
              <span class="text-muted"><?php echo $row->tx_descripcion; ?></span>
              <div class="d-flex align-items-center mt-2">
                <span class="font-weight-bold mr-1 text-dark-75 font-size-lg"><?php echo $row->ca_precio; ?></span>
                <span class="text-muted mr-1">Para</span>
                <span class="font-weight-bold mr-2 text-dark-75 font-size-lg"><?php echo $row->ca_unidades_comprado; ?> Unidad</span>
              </div>
            </div>
            <?php $ca_monto += $row->ca_precio; ?>
            <?php if($row->nb_url_foto != ''): ?>
            <a href="#" class="symbol symbol-70 flex-shrink-0">
              <img src="<?php echo $row->nb_url_foto; ?>" title="" alt="" />
            </a>
          <?php endif; ?>
          </div>

          <div class="separator separator-solid"></div>

                          <?php endforeach; ?>
                       <?php else: ?>
                          <h4 class="mb-4 p-4 text-dark-50">Carrito vacio</h4>
                          <p class="mb-4 p-4 text-dark-50">Ingrese a cartelera y agrege producto</p>
                       <?php endif; ?>

          <!--end::Item-->
        </div>
        <!--end::Wrapper-->
        <!--begin::Purchase-->
        <div class="offcanvas-footer">
          <div class="d-flex align-items-center justify-content-between mb-4">
            <span class="font-weight-bold text-muted font-size-sm mr-2">Total:</span>
            <span class="font-weight-bolder text-dark-50 text-right"><?php echo $ca_monto; ?></span>
          </div>
          <div class="text-right">
            <a href="<?php echo site_url(); ?>compra/menu_carro" class="btn btn-primary text-weight-bold">Comprar</a>
          </div>
        </div>
        <!--end::Purchase-->
      </div>
      <!--end::Content-->
      </span>
    </div>
    <!--end::Quick Cart-->




    <!--end::Chat Panel-->
    <!--begin::Scrolltop-->
    <div id="kt_scrolltop" class="scrolltop">
      <span class="svg-icon">
        <!--begin::Svg Icon | path:assets/media/svg/icons/Navigation/Up-2.svg-->
        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
          <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
            <polygon points="0 0 24 0 24 24 0 24" />
            <rect fill="#000000" opacity="0.3" x="11" y="10" width="2" height="10" rx="1" />
            <path d="M6.70710678,12.7071068 C6.31658249,13.0976311 5.68341751,13.0976311 5.29289322,12.7071068 C4.90236893,12.3165825 4.90236893,11.6834175 5.29289322,11.2928932 L11.2928932,5.29289322 C11.6714722,4.91431428 12.2810586,4.90106866 12.6757246,5.26284586 L18.6757246,10.7628459 C19.0828436,11.1360383 19.1103465,11.7686056 18.7371541,12.1757246 C18.3639617,12.5828436 17.7313944,12.6103465 17.3242754,12.2371541 L12.0300757,7.38413782 L6.70710678,12.7071068 Z" fill="#000000" fill-rule="nonzero" />
          </g>
        </svg>
        <!--end::Svg Icon-->
      </span>
    </div>


    <!--end::Demo Panel-->
    <!--begin::Global Config(global config for global JS scripts)-->
    <script>var KTAppSettings = { "breakpoints": { "sm": 576, "md": 768, "lg": 992, "xl": 1200, "xxl": 1400 }, "colors": { "theme": { "base": { "white": "#ffffff", "primary": "#3699FF", "secondary": "#E5EAEE", "success": "#1BC5BD", "info": "#8950FC", "warning": "#FFA800", "danger": "#F64E60", "light": "#E4E6EF", "dark": "#181C32" }, "light": { "white": "#ffffff", "primary": "#E1F0FF", "secondary": "#EBEDF3", "success": "#C9F7F5", "info": "#EEE5FF", "warning": "#FFF4DE", "danger": "#FFE2E5", "light": "#F3F6F9", "dark": "#D6D6E0" }, "inverse": { "white": "#ffffff", "primary": "#ffffff", "secondary": "#3F4254", "success": "#ffffff", "info": "#ffffff", "warning": "#ffffff", "danger": "#ffffff", "light": "#464E5F", "dark": "#ffffff" } }, "gray": { "gray-100": "#F3F6F9", "gray-200": "#EBEDF3", "gray-300": "#E4E6EF", "gray-400": "#D1D3E0", "gray-500": "#B5B5C3", "gray-600": "#7E8299", "gray-700": "#5E6278", "gray-800": "#3F4254", "gray-900": "#181C32" } }, "font-family": "Poppins" };</script>
    <!--end::Global Config-->
    <!--begin::Global Theme Bundle(used by all pages)-->




    <script src="<?php echo base_url(); ?>assets/plugins/global/plugins.bundle.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/custom/prismjs/prismjs.bundle.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/scripts.bundle.js"></script>
    <!--end::Global Theme Bundle-->
    <!--begin::Page Vendors(used by this page)-->
    <script src="<?php echo base_url(); ?>assets/plugins/custom/fullcalendar/fullcalendar.bundle.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/custom/gmaps/gmaps.js"></script>
    <!--end::Page Vendors-->
    <!--begin::Page Scripts(used by this page)-->
    <script src="<?php echo base_url(); ?>assets/js/pages/widgets.js"></script>

<script src="<?php echo base_url(); ?>assets/plugins/custom/jquery-confirm/js/jquery-confirm.js"></script>

<script src="<?php echo base_url(); ?>assets/js/pages/crud/file-upload/image-input.js"></script>

<script src="<?php echo base_url() ?>assets/plugins/custom/push/Push.js" type="text/javascript"></script>



<script type="text/javascript">


  
          function cerrar_notificacion(co_auditoria)
   {

       $.ajax({
   method: "POST",
   data: {'co_auditoria':co_auditoria},
   url: "<?php echo site_url('auditoria_log/cerrar_notificacion') ?>",
                }).done(function( data ) { 
                   var obj = JSON.parse(data);
   
                 }).fail(function(){
   
               alert('Fallo');
   
                 }); 
 
   }


</script>

    <!--end::Page Scripts-->
  </body>
  <!--end::Body-->
</html>